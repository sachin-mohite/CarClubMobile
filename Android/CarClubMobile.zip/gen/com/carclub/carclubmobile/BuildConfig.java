/** Automatically generated file. DO NOT MODIFY */
package com.carclub.carclubmobile;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}