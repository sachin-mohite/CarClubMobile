	$("#idMainMenuPage").live('pageinit',function(){

		
	});

	$("#idMainMenuPage").live('pageremove',function(){
		$.mobile.loading('show');
	});
	