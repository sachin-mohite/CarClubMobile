	$("#idHelpDeskPage").live('pageinit',function(){
	
		$.mobile.loading('hide');
		
	});
